# 💰 Fluxo de Caixa — MVP

> Controle financeiro básico com Node.js, SQLite e front-end mobile-first.  
> Sem frameworks pesados — código limpo, simples e fácil de expandir.

---

## 📁 Estrutura de Pastas

```
fluxo-caixa/
├── backend/
│   ├── controllers/
│   │   └── transacaoController.js   # Lógica de requisição/resposta HTTP
│   ├── database/
│   │   ├── db.js                    # Conexão singleton com o SQLite
│   │   ├── setup.js                 # Script de criação do banco e tabelas
│   │   └── fluxo_caixa.db           # Arquivo do banco (gerado após setup)
│   ├── models/
│   │   └── transacaoModel.js        # Acesso a dados (queries SQL)
│   └── server.js                    # Servidor HTTP + roteador
├── frontend/
│   ├── css/
│   │   └── style.css                # Estilos mobile-first
│   ├── js/
│   │   └── app.js                   # Lógica do front-end (fetch, DOM)
│   └── index.html                   # Página principal
├── package.json
└── README.md
```

---

## 🚀 Como Rodar Localmente

### Pré-requisitos
- [Node.js](https://nodejs.org/) v18 ou superior
- npm (já vem com o Node.js)

### Passo a passo

```bash
# 1. Entre na pasta do projeto
cd fluxo-caixa

# 2. Instale as dependências
npm install

# 3. Crie o banco de dados SQLite
npm run setup

# 4. Inicie o servidor
npm start
```

Acesse no navegador: **http://localhost:3000**

---

## 🔌 API REST

| Método   | Rota                      | Descrição                          |
|----------|---------------------------|------------------------------------|
| `GET`    | `/api/transacoes`         | Lista todas as transações + saldo  |
| `POST`   | `/api/transacoes`         | Cria nova transação                |
| `DELETE` | `/api/transacoes/:id`     | Remove transação por ID            |
| `GET`    | `/api/saldo`              | Retorna apenas o resumo financeiro |

### Exemplo de payload (POST /api/transacoes)

```json
{
  "descricao": "Salário mensal",
  "valor": 3500.00,
  "tipo": "receita",
  "categoria": "salario",
  "data": "2026-04-28"
}
```

---

## 🗄️ Banco de Dados (SQLite)

Tabela `transacoes`:

| Coluna      | Tipo    | Descrição                              |
|-------------|---------|----------------------------------------|
| `id`        | INTEGER | Chave primária auto-incrementada       |
| `descricao` | TEXT    | Descrição da transação                 |
| `valor`     | REAL    | Valor positivo (tipo define receita/despesa) |
| `tipo`      | TEXT    | `'receita'` ou `'despesa'`             |
| `categoria` | TEXT    | Categoria livre (padrão: `'geral'`)    |
| `data`      | TEXT    | Data no formato `YYYY-MM-DD`           |
| `criado_em` | TEXT    | Timestamp de criação (automático)      |

---

## 🔮 Sugestões de Melhorias Futuras

### Funcionalidades
- [ ] Filtro por período (mês/ano) e categoria
- [ ] Edição de transações existentes
- [ ] Exportação para CSV/PDF
- [ ] Gráficos de receitas vs despesas (Chart.js)
- [ ] Metas de gastos por categoria
- [ ] Suporte a múltiplos usuários com autenticação JWT

### Técnicas
- [ ] Paginação na listagem de transações
- [ ] Testes automatizados (Node.js `assert` ou Jest)
- [ ] Variáveis de ambiente com `.env` (dotenv)
- [ ] Logs estruturados (winston ou pino)
- [ ] Deploy em serviço cloud (Railway, Render, Fly.io)
- [ ] PWA (Progressive Web App) com Service Worker para uso offline

---

## 🛡️ Segurança Implementada

- Validação de dados no servidor (tipo, valor, formato de data)
- Proteção contra path traversal no servidor de arquivos estáticos
- Sanitização de strings antes de persistir no banco
- Queries parametrizadas (prepared statements) — sem SQL injection
- CORS configurado para desenvolvimento local

---

*Projeto gerado como MVP — pronto para ser expandido conforme necessidade.*
